// HIỂN THỊ SẢN PHẨM - PHÂN TRANG
const ITEMS_PER_PAGE = 8;
let currentPage = 1;
function newPrice(a)
{
    return a*0.9;
}
function formatPrice(price)  
{
    return new Intl.NumberFormat('vi-VN', 
    {
        style: 'currency',
        currency: 'VND'
    }).format(price);
}

function renderProducts(page) 
{
    const container = document.getElementById('productContainer');
    container.innerHTML = '';

    const startIndex = (page - 1) * ITEMS_PER_PAGE;
    const endIndex = startIndex + ITEMS_PER_PAGE;
    const paginatedProducts = productArray.slice(startIndex, endIndex);

    paginatedProducts.forEach(product => 
    {
        const productHTML = `
            <div class="grid__column-2-4">
                <a class="home-product-item">
                    <div class="home-product-item__img" style="background-image: url(${product.img});"></div>
                    <h4 class="home-product-item__name">${product.name}</h4>
                    <div class="home-product-item__price">
                        <span class="home-product-item__price-old">${formatPrice(product.oldPrice)}</span>
                        <span class="home-product-item__price-current">${formatPrice(newPrice(product.oldPrice))}</span>
                    </div>
                    <div class="add-to-cart">
                        <span class="add-to-cart-text">Thêm vào giỏ</span>
                        <i class="add-to-cart-icon fa-solid fa-gift"></i>
                    </div>
                </a>
            </div>
        `;
        container.insertAdjacentHTML('beforeend', productHTML);
    });
    renderPagination();
}

function renderPagination() 
{
    const paginationContainer = document.getElementById('pagination');
    const totalPages = Math.ceil(productArray.length / ITEMS_PER_PAGE);
    
    let paginationHTML = `
        <li class="pagination-item ${currentPage === 1 ? 'disabled' : ''}">
            <a href="#" class="pagination-item__link" onclick="event.preventDefault(); changePage(${currentPage - 1})">
                <i class="pagination-item__icon fa-solid fa-angle-left"></i>
            </a>
        </li>
    `;
    // Các nút số trang
    for (let i = 1; i <= totalPages; i++) {
        paginationHTML += `
            <li class="pagination-item ${currentPage === i ? 'pagination-item--active' : ''}">
                <a href="#" class="pagination-item__link" onclick="event.preventDefault(); changePage(${i})">${i}</a>
            </li>
        `;
    }
    paginationHTML += `
        <li class="pagination-item ${currentPage === totalPages ? 'disabled' : ''}">
            <a href="#" class="pagination-item__link" onclick="event.preventDefault(); changePage(${currentPage + 1})">
                <i class="pagination-item__icon fa-solid fa-angle-right"></i>
            </a>
        </li>
    `;
    paginationContainer.innerHTML = paginationHTML;
}
function changePage(page) 
{
    const totalPages = Math.ceil(productArray.length / ITEMS_PER_PAGE);    
    // Kiểm tra giới hạn trang
    if (page < 1 || page > totalPages) {
        return;
    }
    currentPage = page;
    renderProducts(currentPage);
    // Scroll to top
    document.getElementById('productContainer').scrollIntoView({
        behavior: 'smooth'
    });
}

// Khởi tạo lại khi trang load
document.addEventListener('DOMContentLoaded', () => {
    TRANGCHU();
    Dangxuat();
    renderProducts(currentPage);
});
------
document.querySelectorAll('.sub-nav-links-text a').forEach(link => {
    link.addEventListener('click', (event) => {
        event.preventDefault();
        const brandId = link.getAttribute('href').substring(1); // Lấy brandId từ href
        currentPage = 1; // Reset trang hiện tại
        filterAndRenderProducts(brandId);
    });
});

function filterProducts(brandId) {
    return productArray.filter(product => product.brandId === brandId);
}

function filterAndRenderProducts(brandId) {
    const filteredProducts = filterProducts(brandId);
    renderProducts(filteredProducts, currentPage);
}

function renderProducts(products, page) {
    const container = document.getElementById('productContainer');
    container.innerHTML = '';

    const startIndex = (page - 1) * ITEMS_PER_PAGE;
    const endIndex = startIndex + ITEMS_PER_PAGE;
    const paginatedProducts = products.slice(startIndex, endIndex);

    paginatedProducts.forEach(product => 
    {
        const productHTML = `
            <div class="grid__column-2-4">
                <a class="home-product-item">
                    <div class="home-product-item__img" style="background-image: url(${product.img});"></div>
                    <h4 class="home-product-item__name">${product.name}</h4>
                    <div class="home-product-item__price">
                        <span class="home-product-item__price-old">${formatPrice(product.oldPrice)}</span>
                        <span class="home-product-item__price-current">${formatPrice(newPrice(product.oldPrice))}</span>
                    </div>
                    <div class="add-to-cart">
                        <span class="add-to-cart-text">Thêm vào giỏ</span>
                        <i class="add-to-cart-icon fa-solid fa-gift"></i>
                    </div>
                </a>
            </div>
        `;
        container.insertAdjacentHTML('beforeend', productHTML);
    });
    renderPagination();
}



const ITEMS_PER_PAGE = 8;
let currentPage = 1;
let currentProducts = productArray;

function newPrice(a) {
    return a * 0.9 + 1000;
}

function formatPrice(price) {
    return new Intl.NumberFormat('vi-VN', {
        style: 'currency',
        currency: 'VND'
    }).format(price);
}

// Hàm xáo trộn mảng
function shuffleArray(array) {
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]];
    }
    return array;
}

// Lắng nghe sự kiện click cho các liên kết sản phẩm
document.querySelectorAll('.sub-nav-links-text a').forEach(link => {
    link.addEventListener('click', (event) => {
        event.preventDefault();
        const brandId = link.getAttribute('href').substring(1); // Lấy brandId từ href
        currentPage = 1; // Reset trang hiện tại

        if (brandId === 'TRANG_CHU') {
            currentProducts = shuffleArray(productArray.slice()); // Xáo trộn mảng sản phẩm khi vào trang chủ
        } else {
            currentProducts = filterProducts(brandId);
        }
        renderProducts(currentProducts, currentPage);
    });
});

// Lắng nghe sự kiện click cho các liên kết sắp xếp
document.querySelectorAll('.select-input__link').forEach(link => {
    link.addEventListener('click', (event) => {
        event.preventDefault();
        const sortType = link.textContent.includes('Tăng') ? 'asc' : 'desc';

        currentProducts.sort((a, b) => {
            if (sortType === 'asc') {
                return a.oldPrice - b.oldPrice;
            } else {
                return b.oldPrice - a.oldPrice;
            }
        });

        currentPage = 1; // Reset trang hiện tại
        renderProducts(currentProducts, currentPage);
    });
});

// Lắng nghe sự kiện input cho ô tìm kiếm và nút tìm kiếm
const searchInput = document.querySelector('.search-input');
const searchButton = document.querySelector('.header__search-btn');

function performSearch() {
    const searchTerm = searchInput.value.toLowerCase();
    const filteredProducts = productArray.filter(product => {
        return product.name.toLowerCase().includes(searchTerm);
    });

    currentPage = 1; // Reset trang hiện tại
    renderProducts(filteredProducts, currentPage);
}

searchInput.addEventListener('keydown', (event) => {
    if (event.key === 'Enter') {
        event.preventDefault();
        performSearch();
    }
});

searchButton.addEventListener('click', (event) => {
    event.preventDefault();
    performSearch();
});

function filterProducts(brandId) {
    return productArray.filter(product => product.brandId.toUpperCase() === brandId.toUpperCase());
}

function renderProducts(products, page) {
    const container = document.getElementById('productContainer');
    container.innerHTML = '';

    const startIndex = (page - 1) * ITEMS_PER_PAGE;
    const endIndex = startIndex + ITEMS_PER_PAGE;
    const paginatedProducts = products.slice(startIndex, endIndex);

    paginatedProducts.forEach(product => {
        const productHTML = `
            <div class="grid__column-2-4">
                <a class="home-product-item">
                    <div class="home-product-item__img" style="background-image: url(${product.img});"></div>
                    <h4 class="home-product-item__name">${product.name}</h4>
                    <div class="home-product-item__price">
                        <span class="home-product-item__price-old">${formatPrice(product.oldPrice)}</span>
                        <span class="home-product-item__price-current">${formatPrice(newPrice(product.oldPrice))}</span>
                    </div>
                    <div class="add-to-cart">
                        <span class="add-to-cart-text">Thêm vào giỏ</span>
                        <i class="add-to-cart-icon fa-solid fa-gift"></i>
                    </div>
                </a>
            </div>
        `;
        container.insertAdjacentHTML('beforeend', productHTML);
    });
    renderPagination(products);
}

function renderPagination(products) {
    const paginationContainer = document.getElementById('pagination');
    const totalPages = Math.ceil(products.length / ITEMS_PER_PAGE);

    let paginationHTML = `
        <li class="pagination-item ${currentPage === 1 ? 'disabled' : ''}">
            <a href="#" class="pagination-item__link" onclick="event.preventDefault(); changePage(${currentPage - 1})">
                <i class="pagination-item__icon fa-solid fa-angle-left"></i>
            </a>
        </li>
    `;

    for (let i = 1; i <= totalPages; i++) {
        paginationHTML += `
            <li class="pagination-item ${currentPage === i ? 'pagination-item--active' : ''}">
                <a href="#" class="pagination-item__link" onclick="event.preventDefault(); changePage(${i})">${i}</a>
            </li>
        `;
    }

    paginationHTML += `
        <li class="pagination-item ${currentPage === totalPages ? 'disabled' : ''}">
            <a href="#" class="pagination-item__link" onclick="event.preventDefault(); changePage(${currentPage + 1})">
                <i class="pagination-item__icon fa-solid fa-angle-right"></i>
            </a>
        </li>
    `;

    paginationContainer.innerHTML = paginationHTML;
}

function changePage(page) {
---
const ITEMS_PER_PAGE = 8;
let currentPage = 1;
let currentProducts = productArray;
let allProducts = productArray;

function newPrice(a) {
    return a * 0.9 + 7000;
}

function formatPrice(price) {
    return new Intl.NumberFormat('vi-VN', {
        style: 'currency',
        currency: 'VND'
    }).format(price);
}

function shuffleArray(array) {
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]];
    }
    return array;
}

// Lắng nghe sự kiện click cho các liên kết sản phẩm
document.querySelectorAll('.sub-nav-links-text a').forEach(link => {
    link.addEventListener('click', (event) => {
        event.preventDefault();
        const brandId = link.getAttribute('href').substring(1); // Lấy brandId từ href
        currentPage = 1; // Reset trang hiện tại

        if (brandId === 'TRANG_CHU') {
            currentProducts = shuffleArray(productArray.slice()); // Xáo trộn mảng sản phẩm khi vào trang chủ
        } else {
            currentProducts = shuffleArray(filterProductsByBrand(brandId));
        }
        allProducts = currentProducts; // Update allProducts
        renderProducts(currentProducts, currentPage);
    });
});

// Lắng nghe sự kiện click cho các liên kết sắp xếp
document.querySelectorAll('.select-input__link').forEach(link => {
    link.addEventListener('click', (event) => {
        event.preventDefault();
        const sortType = link.textContent.includes('Tăng') ? 'asc' : 'desc';

        currentProducts.sort((a, b) => {
            if (sortType === 'asc') {
                return a.oldPrice - b.oldPrice;
            } else {
                return b.oldPrice - a.oldPrice;
            }
        });

        currentPage = 1; // Reset trang hiện tại
        renderProducts(currentProducts, currentPage);
    });
});

// Lắng nghe sự kiện input cho ô tìm kiếm và nút tìm kiếm
const searchInput = document.querySelector('.search-input');
const searchButton = document.querySelector('.header__search-btn');

function performSearch() {
    const searchTerm = searchInput.value.toLowerCase();
    const filteredProducts = allProducts.filter(product => {
        return product.name.toLowerCase().includes(searchTerm);
    });

    currentPage = 1; // Reset trang hiện tại
    currentProducts = filteredProducts; // Update currentProducts
    renderProducts(filteredProducts, currentPage);
}

searchInput.addEventListener('keydown', (event) => {
    if (event.key === 'Enter') {
        event.preventDefault();
        performSearch();
    }
});

searchButton.addEventListener('click', (event) => {
    event.preventDefault();
    performSearch();
});

document.querySelector('.btnprocess').addEventListener('click', filterProducts);

function filterProductsByBrand(brandId) {
    return productArray.filter(product => product.brandId.toUpperCase() === brandId.toUpperCase());
}

function filterProducts() {
    const minPrice = parseInt(document.querySelector('.input-min').value);
    const maxPrice = parseInt(document.querySelector('.input-max').value);

    // Get values from range inputs
    const minRangeValue = parseInt(document.querySelector('.range-min').value);
    const maxRangeValue = parseInt(document.querySelector('.range-max').value);

    // Consider both input and range values
    const adjustedMinPrice = Math.max(minPrice, minRangeValue);
    const adjustedMaxPrice = Math.min(maxPrice, maxRangeValue);

    const selectedBrands = Array.from(document.querySelectorAll('.category-list .checkbox input:checked')).map(checkbox => checkbox.value.toUpperCase());
    const searchTerm = document.querySelector('.auto-form__input2').value.toLowerCase();

    const filteredProducts = allProducts.filter(product => {
        const productPrice = parseInt(product.oldPrice);
        return (
            productPrice >= adjustedMinPrice &&
            productPrice <= adjustedMaxPrice &&
            (selectedBrands.length === 0 || selectedBrands.includes(product.brandId.toUpperCase())) &&
            product.name.toLowerCase().includes(searchTerm)
        );
    });

    currentPage = 1; // Reset trang hiện tại
    currentProducts = filteredProducts;
    renderProducts(currentProducts, currentPage);
}

function renderProducts(products, page) {
    const container = document.getElementById('productContainer');
    container.innerHTML = '';

    const startIndex = (page - 1) * ITEMS_PER_PAGE;
    const endIndex = startIndex + ITEMS_PER_PAGE;
    const paginatedProducts = products.slice(startIndex, endIndex);

    paginatedProducts.forEach(product => {
        const productHTML = `
            <div class="grid__column-2-4">
                <a class="home-product-item">
                    <div class="home-product-item__img" style="background-image: url(${product.img});"></div>
                    <h4 class="home-product-item__name">${product.name}</h4>
                    <div class="home-product-item__price">
                        <span class="home-product-item__price-old">${formatPrice(product.oldPrice)}</span>
                        <span class="home-product-item__price-current">${formatPrice(newPrice(product.oldPrice))}</span>
                    </div>
                    <div class="add-to-cart">
                        <span class="add-to-cart-text">Thêm vào giỏ</span>
                        <i class="add-to-cart-icon fa-solid fa-gift"></i>
                    </div>
                </a>
            </div>
        `;
        container.insertAdjacentHTML('beforeend', productHTML);
    });
    renderPagination(products);
}

function renderPagination(products) {
    const paginationContainer = document.getElementById('pagination');
    const totalPages = Math.ceil(products.length / ITEMS_PER_PAGE);

    let paginationHTML =
---
const rangeInput = document.querySelectorAll(".range-input input"),
priceInput = document.querySelectorAll(".price-input input"),
range = document.querySelector(".slider .progress");

let priceGap = 1000;

function formatNumber(num) {
return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
}

function unformatNumber(str) {
return parseInt(str.replace(/\./g, ""));
}

// Function to synchronize and format price inputs with range inputs
function updatePriceInput(inputElement, value) {
inputElement.value = formatNumber(value);
}

// Function to synchronize and format range inputs with price inputs
function updateRangeInput(rangeElement, value) {
rangeElement.value = value;
}

priceInput.forEach(input => {
input.addEventListener("input", e => {
    let minPrice = unformatNumber(priceInput[0].value),
        maxPrice = unformatNumber(priceInput[1].value);

    if (!isNaN(unformatNumber(e.target.value))) {
        e.target.value = formatNumber(unformatNumber(e.target.value));
    }

    if ((maxPrice - minPrice >= priceGap) && maxPrice <= rangeInput[1].max) {
        if (e.target.className === "input-min") {
            updateRangeInput(rangeInput[0], minPrice);
            range.style.left = ((minPrice / rangeInput[0].max) * 100) + "%";
        } else {
            updateRangeInput(rangeInput[1], maxPrice);
            range.style.right = 100 - (maxPrice / rangeInput[1].max) * 100 + "%";
        }
    }
});

input.addEventListener("blur", e => {
    e.target.value = formatNumber(unformatNumber(e.target.value));
});
});

rangeInput.forEach(input => {
input.addEventListener("input", e => {
    let minVal = parseInt(rangeInput[0].value),
        maxVal = parseInt(rangeInput[1].value);

    if ((maxVal - minVal) < priceGap) {
        if (e.target.className === "range-min") {
            updatePriceInput(priceInput[0], maxVal - priceGap);
        } else {
            updatePriceInput(priceInput[1], minVal + priceGap);
        }
    } else {
        updatePriceInput(priceInput[0], minVal);
        updatePriceInput(priceInput[1], maxVal);
        range.style.left = ((minVal / rangeInput[0].max) * 100) + "%";
        range.style.right = 100 - (maxVal / rangeInput[1].max) * 100 + "%";
    }
});
});


// Synchronize range inputs with text inputs
const rangeMinInput = document.querySelector('.range-min');
const rangeMaxInput = document.querySelector('.range-max');
const checkboxAll = document.querySelector('.checkbox.value-all input');
const btnReset = document.querySelector('.btnReset'); // Reset button

rangeMinInput.addEventListener('input', (event) => {
    document.querySelector('.input-min').value = formatNumber(event.target.value);
    resetFilters();
});

rangeMaxInput.addEventListener('input', (event) => {
    document.querySelector('.input-max').value = formatNumber(event.target.value);
    resetFilters();
});

checkboxAll.addEventListener('change', () => {
    // If "TẤT CẢ" checkbox is checked, reset other brand checkboxes
    const otherCheckboxes = document.querySelectorAll('.category-list .checkbox input:not(.value-all input)');
    otherCheckboxes.forEach(checkbox => {
        checkbox.checked = false;
    });

    // Reset filters
    resetFilters();
});

document.querySelectorAll('.category-list .checkbox input:not(.value-all input)').forEach(checkbox => {
    checkbox.addEventListener('change', () => {
        if (checkbox.checked) {
            checkboxAll.checked = false;
        }
        // Reset filters
        resetFilters();
    });
});

// Reset filters and re-render the original product list
function resetFilters() {
    currentProducts = productArray.slice(); // Reset to the original product list
    renderProducts(currentProducts, currentPage);
}

// Filter products based on current filters
function filterProducts() {
    const minPrice = parseInt(document.querySelector('.input-min').value.replace(/\./g, ''));
    const maxPrice = parseInt(document.querySelector('.input-max').value.replace(/\./g, ''));

    // Get values from range inputs
    const minRangeValue = parseInt(document.querySelector('.range-min').value);
    const maxRangeValue = parseInt(document.querySelector('.range-max').value);

    // Consider both input and range values
    const adjustedMinPrice = Math.max(minPrice, minRangeValue);
    const adjustedMaxPrice = Math.min(maxPrice, maxRangeValue);

    // Get selected brands
    let selectedBrands = [];
    if (!checkboxAll.checked) {
        selectedBrands = Array.from(document.querySelectorAll('.category-list .checkbox input:checked')).map(checkbox => checkbox.value.toUpperCase());
    }

    const searchTerm = document.querySelector('.auto-form__input2').value.toLowerCase();

    const filteredProducts = allProducts.filter(product => {
        const productPrice = parseInt(product.oldPrice);
        return (
            productPrice >= adjustedMinPrice &&
            productPrice <= adjustedMaxPrice &&
            (selectedBrands.length === 0 || selectedBrands.includes(product.brandId.toUpperCase())) &&
            product.name.toLowerCase().includes(searchTerm)
        );
    });

    currentPage = 1; // Reset current page
    currentProducts = filteredProducts;
    renderProducts(currentProducts, currentPage);
}

// Add event listener to "Xử Lý" button to process filters
document.querySelector('.btnprocess').addEventListener('click', filterProducts);

// Add event listener to "Reset" button to clear filters
btnReset.addEventListener('click', () => {
    // Reset all inputs
    document.querySelector('.input-min').value = "0";
    document.querySelector('.input-max').value = "50000000";
    document.querySelector('.range-min').value = "0";
    document.querySelector('.range-max').value = "50000000";
    checkboxAll.checked = false;
    document.querySelectorAll('.category-list .checkbox input:not(.value-all input)').forEach(checkbox => {
        checkbox.checked = false;
    });
    document.querySelector('.auto-form__input2').value = "";

    resetFilters(); // Re-render original product list
});

function filterProductsByBrand(brandId) {
    return productArray.filter(product => product.brandId.toUpperCase() === brandId.toUpperCase());
}

function renderProducts(products, page) {
    const container = document.getElementById('productContainer');
    container.innerHTML = '';

    const startIndex = (page - 1) * ITEMS_PER_PAGE;
    const endIndex = startIndex + ITEMS_PER_PAGE;
    const paginatedProducts = products.slice(startIndex, endIndex);

    paginatedProducts.forEach(product => {
        const productHTML = `
            <div class="grid__column-2-4">
                <a class="home-product-item">
                    <div class="home-product-item__img" style="background-image: url(${product.img});"></div>
                    <h4 class="home-product-item__name">${product.name}</h4>
                    <div class="home-product-item__price">
                        <span class="home-product-item__price-old">${formatNumber(product.oldPrice)}</span>
                        <span class="home-product-item__price-current">${formatNumber(newPrice(product.oldPrice))}</span>
                    </div>
                    <div class="add-to-cart">
                        <span class="add-to-cart-text">Thêm vào giỏ</span>
                        <i class="add-to-cart-icon fa-solid fa-gift"></i>
                    </div>
                </a>
            </div>
        `;
        container.insertAdjacentHTML('beforeend', productHTML);
    });
    renderPagination(products);
}

function renderPagination(products) {
    const paginationContainer = document.getElementById('pagination');
    const totalPages = Math.ceil(products.length / ITEMS_PER_PAGE);

    let paginationHTML = `
        <li class="pagination-item ${currentPage === 1 ? 'disabled' : ''}">
            <a href="#" class="pagination-item__link" onclick="event.preventDefault(); changePage(${currentPage - 1})">
                <i class="pagination-item__icon fa-solid fa-angle-left"></i>
            </a>
        </li>
    `;

    for (let i = 1; i <= totalPages; i++) {
        paginationHTML += `
            <li class="pagination-item ${currentPage === i ? 'pagination-item--active' : ''}">
                <a href="#" class="pagination-item__link" onclick="event.preventDefault(); changePage(${i})">${i}</a>
            </li>
        `;
    }

    paginationHTML += `
        <li class="pagination-item ${currentPage === totalPages ? 'disabled' : ''}">
            <a href="#" class="pagination-item__link" onclick="event.preventDefault(); changePage(${current